/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avltree;

import espol.edu.ec.ABB;
import espol.edu.ec.Constantes;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 *
 * @author Christian Guerrero
 */
public class AVLTree extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button("Agregar");        
        Button delete = new Button("Eliminar");
        
        TextField tf = new TextField();
        TextField tfDelete = new TextField();
        Circle ci = new Circle(23);
        ABB ab = new ABB(Integer::compareTo);
        HBox hb = new HBox(7);
        HBox hb2 = new HBox(7);
        hb.getChildren().addAll(btn,tf);        
        hb2.getChildren().addAll(delete,tfDelete);
        VBox vb = new VBox(5,hb,hb2,ab);
        hb.setAlignment(Pos.TOP_CENTER);
        hb2.setAlignment(Pos.TOP_CENTER);
        vb.setAlignment(Pos.TOP_CENTER);
                
        
        
       
       // ab.add(5);
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ab.add(Integer.parseInt(tf.getText()));
                ab.mostrarArbol();
                System.out.println("Hello World!");
                tf.setText("");
            }
        });
    
           delete.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ab.remove(Integer.parseInt(tfDelete.getText()));
                ab.mostrarArbol();
                System.out.println("Hello World!");
                tfDelete.setText("");
            }
        });
        
        StackPane root = new StackPane();
        
        Scene scene = new Scene(vb,Constantes.MAX_WIDTH,Constantes.MAX_HEIGHT);
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
