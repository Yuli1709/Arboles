/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package espol.edu.ec;

import javafx.geometry.Pos;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

/**
 *
 * @author Administrador
 */
public class Node extends StackPane{
    private Node left;
    private Node right;
    private Integer data;
    private Text text;
    private Circle content;
    
    
     public Node(Integer data){
        this.data=data;
        content = new Circle();
        left=right=null;
        CicleNode();
    }
    private void CicleNode(){
        text= new Text(String.valueOf(data));
        text.setFont(Font.font(20));
        content.setRadius(20);
        content.setFill(Color.WHITE);
        super.getChildren().addAll(content,text);
        super.setAlignment(Pos.CENTER);               
    }

    public Node getLeft() {
        return left;
    }

    public void setLeft(Node left) {
        this.left = left;
    }

    public Node getRight() {
        return right;
    }

    public void setRight(Node right) {
        this.right = right;
    }

    public Integer getData() {
        return data;
    }

    public void setData(Integer data) {
        this.data = data;
    }

    
    public Text getText() {
        return text;
    }

    public void setText(Text text) {
        this.text = text;
    }

    public Circle getContent() {
        return content;
    }

    public void setContent(Circle content) {
        this.content = content;
    }
    
    
    
}
