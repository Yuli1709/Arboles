/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package espol.edu.ec;

import java.util.Comparator;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import static javafx.scene.paint.Color.color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

/**
 *
 * @author Administrador
 */
public class ABB extends Pane{
    private Node root;
    private Node ro;
    private Comparator<Integer> f;
    private double radius = 15;
    private double vGap = 50;
    public ABB(Comparator<Integer> f){
       this.f=f;
       this.root=null;
       
    }
    // este es el metodo que hace la maravilla!!! 
    // se crea paralelamente cada circulo segun vaya ingresando en  la estrucutura
    public void mostrarArbol(){
        this.getChildren().clear();
        if(this.getRoot()!=null){
            showArbol(root, getWidth() / 2, vGap, getWidth() / 4, Color.MEDIUMPURPLE);
        }
    }
    private void showArbol(Node root, double x, double y, double hGap, Color color){
        if(root.getLeft() != null){
            getChildren().add(new Line(x - hGap, y + vGap, x, y));
            showArbol(root.getLeft(), x - hGap, y + vGap, hGap / 2,color);
        }

        if (root.getRight() != null){
            getChildren().add(new Line(x + hGap, y + vGap, x, y));
            showArbol(root.getRight(), x + hGap, y + vGap, hGap / 2, color);
        }
        Circle circle = new Circle(x, y, 20);
        circle.setFill(Color.WHITE);
        circle.setStroke(Color.BLACK);
        getChildren().addAll(circle, new Text(x - 4, y + 4, root.getData() + ""));
    
    }
    
    public boolean add(Integer data){
       if(data==null) return false;
       this.root=add(data,root);
      return true;
    }
    private Node add(Integer data,Node p){
        if(p==null){
            p= new Node(data);
            p.setTranslateX(Constantes.X/-20);
            p.setTranslateY(0);
        }else if(f.compare(data, p.getData())>0){
           // mostrarArbol();
            Node v = new Node(0);
            p.setTranslateX(p.getTranslateX()+Constantes.MAX_WIDTH/4);
            p.setTranslateY(p.getTranslateY()+100);
            p.setRight(add(data, p.getRight()));
        }else if(f.compare(data, p.getData())<0){
          //  mostrarArbol();
            Node v = new Node(0);
            p.setTranslateX(p.getTranslateX() - Constantes.MAX_WIDTH/4);
            p.setTranslateY(p.getTranslateY() + 100);
            p.setLeft(add(data, p.getLeft()));
        }    
        return p;
    }
    public boolean isEmpty(){
        return root==null;
    }
     public boolean remove ( Integer data){
        if(this.isEmpty()||data==null){
            return false;
        }else{
            this.root= remove(data,this.root);
            
            return true;
        }
    }
    
    private Node remove(Integer data, Node p){
        if(p==null){
            return p;
        }else if (f.compare(data, p.getData())>0){
            p.setRight(remove(data,p.getRight()));
        }else if (f.compare(data, p.getData())<0){
            p.setLeft(remove(data,p.getLeft()));
        }else {
            if(p.getLeft()!=null && p.getRight()!=null){
                p.setData(min(p.getRight()));
                p.setRight(remove(p.getData(),p.getRight()));
            }else {
                p=(p.getLeft()!=null)? p.getLeft(): p.getRight();
            }
        }
        return p;
    }
    public Integer min(){
        if(this.isEmpty()){
            return null;
        }else {
            return min(root);
        }
    }
    
    private Integer min(Node p ){
        if(p.getLeft()==null){
            return p.getData();
        }else{
            return min(p.getLeft());
        }
    }
    
    
    
   

   public void preOrden(){
       preOrden(root);
       
   }
   private void preOrden(Node nodo){
       if(nodo!=null){
            preOrden(nodo.getLeft());
            System.out.print(" "+nodo.getData());
            preOrden(nodo.getRight());
       }
   }
    public boolean contains(Integer data) {
        if(data == null || root==null)
            return false;
        return contains(data, root);
    }
    
    private boolean contains(Integer data, Node nodo) {
        if(nodo == null)
            return false;
        else if(f.compare(data, nodo.getData()) == 0)
            return true;
        else if(f.compare(data, nodo.getData()) > 0)
            return contains(data, nodo.getRight());
        return contains(data, nodo.getLeft());
    }

    public Node getRoot() {
        return root;
    }

   

    
    
}
