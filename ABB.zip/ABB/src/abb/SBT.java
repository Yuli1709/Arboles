/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abb;

import java.util.Comparator;

/**
 *
 * @author Tania
 */
public class SBT <E> { //arbol binario de Buqueda
    //los elementos mayores estan a la derecha y los elementos menores estan a la izquierda
    
    private Node<E> root;
    private Comparator<E> f;
    
    public SBT(Comparator<E> f) {
        this.f=f;
        this.root=null;
    }
    
    public boolean isEmpty(){
        return root==null;
    }
 
    public int height(){
        return height(root);
    }
    
    private int height(Node<E> n){
        if(n==null) return 0;
        return 1+ Math.max(height(n.getLeft()),height(n.getRight()));
    }
    
    public int totalNodos(){
        return totalNodos(root);
    }
    
    private int totalNodos(Node<E> n){
        if (n==null) return 0;
        return 1 + totalNodos(n.getLeft())+ totalNodos(n.getRight());
    }
    
    public int contarHojas(){
        return contarHojas(root);
    }
    private int contarHojas(Node<E> n){
        if(n==null) return 0;
        else if(n.getLeft()==null&& n.getRight()==null){
            return 1;
        }return contarHojas(n.getLeft())+ contarHojas(n.getRight());
    }
    
    public boolean add(E element){
        if(element==null)return false;
        this.root=add(element,root);
        return true;
    }
    
    private Node<E> add(E element, Node<E> n){
        if(n==null){
            n= new Node<>(element);
        }else if(f.compare(element, n.getData())>0){
            n.setRight(add(element,n.getRight()));
        }else if(f.compare(element, n.getData())<0){
            n.setLeft(add(element,n.getLeft()));
        }return n;
    }
     
    public E max(){
        return max(root);
    }
    private E max(Node<E> n){
        if(n==null)return null;
        else if(n.getRight()==null){
            return n.getData();
        }else
            return max(n.getRight());
    }
    
    public E min(){
        return min(root);
    }
    private E min(Node<E> n){
        if(n==null)return null;
        else if(n.getLeft()==null){
            return n.getData();
        }else
            return max(n.getLeft());
    }
    
    public boolean remove(E element){
        if(element==null|| isEmpty()) return false;
        this.root=remove(element,root);
        return true;
    }
    
    private Node<E> remove(E element, Node<E> n){
        if(n==null) return n;
        else if(f.compare(element, n.getData())>0){
            n.setRight(remove(element,n.getRight()));
        }else if(f.compare(element, n.getData())<0){
            n.setLeft(remove(element,n.getLeft()));
        }else if(n.getLeft()!=null && n.getRight()!=null){
            n.setData(max(n.getLeft()));
            n.setLeft(remove(n.getData(),n.getLeft()));
        }else
            n=(n.getLeft()!=null)?n.getLeft():n.getRight();
        return n;
    }
    
    public boolean contains(E element){
        if(element==null|| isEmpty()) return false;
        return contains(element,root);
         
    }
    
    private boolean contains(E element, Node<E> n){
        if(n==null) return false;
        else if(f.compare(element,n.getData()) == 0)
            return true;
        else if(f.compare(element, n.getData())>0){
            contains(element,n.getRight());
        }else if(f.compare(element, n.getData())<0){
            contains(element,n.getLeft());
        }return true;
    }

    public void posOrde(){
        posOrden(root);
    }
    private void posOrden(Node<E> n){
        if(n!=null){
            posOrden(n.getLeft());
            posOrden(n.getRight());
            System.out.println(n.getData());
        }
    }
     
    public void preOrden(){
        preOrden(root);
    }
    private void preOrden(Node<E> n){
        if(n!=null){
            System.out.println(n.getData());
            preOrden(n.getLeft());
            preOrden(n.getRight());           
        }
    }
    
    public void enOrden(){
        enOrden(root);
    }
    private void enOrden(Node<E> n){
        if(n!=null){
            enOrden(n.getLeft());
            System.out.println(n.getData());            
            enOrden(n.getRight());            
        }
    }
    
    public SBT<E> mirror(){
        SBT<E> tree = new SBT<>(this.f);
        tree.root = mirror(this.root);
        return tree;
    }
    private Node<E> mirror(Node<E> n) {
        if(n==null)
            return n;        
        if (n.getData().equals(this.root.getData()) || (n.getRight() != null && n.getLeft() != null)) {
            return invert(n);
        }
        return new Node<>(n.getData());
    }
    
    private Node<E> invert(Node<E> n) {
        Node<E> r = new Node<>(n.getData());
        r.setRight(mirror(n.getLeft()));
        r.setLeft(mirror(n.getRight()));
        return r;
    }
    
    public int nivel(E element){
        if (element==null|| isEmpty()|| this.contains(element)) return -1;
        return nivel(element, root);
    }
    
    private int nivel(E element, Node<E> n){
        int num=height()-1;
        if(n==null) return -1;
        
        else if(f.compare(element,n.getData()) == 0){
            return num;
        }else if(f.compare(element, n.getData())>0){
            return nivel(element,n.getRight())-1;            
        }else if(f.compare(element, n.getData())<0){           
            return nivel(element,n.getLeft())-1;
        }return -1;
    }
        
    @Override
    public boolean equals(Object obj) {
        if (this == null || obj == null) 
            return false;
        else if (!(this instanceof SBT) || !(obj instanceof SBT)){ 
            return false;
        }
        final SBT<E> other = (SBT<E>) obj;
        return equals(this.root,other.root);    
    }
    private boolean equals(Node n1, Node n2){
        if(n1 == null && n2 == null)
            return true;
        else if((n1 == null && n2 != null) || (n1 != null && n2 == null))
            return false;
        else if(!n1.getData().equals(n2.getData())) {
            return false;
        }

        return equals(n1.getLeft(), n2.getLeft()) && equals(n1.getRight(), n2.getRight());
    } 

    @Override
    public int hashCode() {
        return super.hashCode(); //To change body of generated methods, choose Tools | Templates.
    }
    
}
