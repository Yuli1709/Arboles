/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abb;

/**
 *
 * @author Tania
 */
public class ABB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SBT<Integer> arbol = new SBT<>((Integer e1,Integer e2) -> e1-e2);
        SBT<Integer> arbol2 = new SBT<>((Integer e1,Integer e2) -> e1-e2);
        SBT<Integer> arbol3 = new SBT<>((Integer e1,Integer e2) -> e1-e2);
        arbol.add(5);
        arbol.add(10);
        arbol.add(2);
        arbol.add(3);
        arbol.add(6);
        arbol.add(11);
        arbol.add(1);
        System.out.println(arbol.contains(10));
        System.out.println(arbol.contains(30));
        arbol2.add(5);
        arbol2.add(10);
        arbol2.add(2);
        arbol2.add(3);
        arbol2.add(6);
        arbol2.add(11);
        arbol2.add(1);
        arbol3.add(6);
        System.out.println(arbol.equals(arbol2));
        System.out.println(arbol.equals(arbol3));
        System.out.println("ARBOL INICIAL");
        arbol.preOrden();
        System.out.println("ARBOL MIRROR");
        SBT<Integer> ab = arbol.mirror();
        ab.preOrden();
        System.out.println("NIVEL ELEMENTO");
        System.out.println(arbol.nivel(44));
    }
    
}
