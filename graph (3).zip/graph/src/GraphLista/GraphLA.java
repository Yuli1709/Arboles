/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphLista;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;


/**
 *
 * @author CltControl
 */
public class GraphLA <E> {
    private List<Vertex<E>> vertexes;
    private boolean directed;

    public GraphLA(boolean directed) {
        this.directed = directed;
        this.vertexes=new LinkedList<>();
    }
    
    public boolean isEmpty(){
        return vertexes.isEmpty();
    }
    
    public boolean addVertex(E data){
        if(data==null) return false;
        Vertex<E> v=new Vertex<>(data);
        if(vertexes.contains(v))return false;
        return vertexes.add(v);
    }
    
    public boolean addEdge(E origen, E destino, int peso){
        if(origen==null||destino==null) return false;
        Vertex<E> vo=searchVertex(origen);
        Vertex<E> vd=searchVertex(destino);
        if(vo==null||vd==null) return false;
        Edge<E> e=new Edge<>(vo,vd,peso);
        if(vo.getEdges().contains(e)) return false;
        vo.getEdges().add(e);
        if(!directed){
             e=new Edge<>(vd,vo,peso);
             vd.getEdges().add(e);
        }return true;
    }
    
    private Vertex<E> searchVertex(E data){
        for(Vertex<E> v:vertexes){
            if(v.getData().equals(data))return v;
        }return null;
    }
    
    public boolean removeVertex(E data){
        if(data==null) return false;
        Vertex<E> v=searchVertex(data);
        if(v==null) return false;
        ListIterator<Vertex<E>> itv=vertexes.listIterator();
        while(itv.hasNext()){
            Vertex<E> vl=itv.next();
            ListIterator<Edge<E>> ite=vl.getEdges().listIterator();
            while(ite.hasNext()){
                Edge<E> e=ite.next();
                if(e.getDestino().equals(v)) ite.remove();
            }
        }return true;
    }   
    
    public boolean removeEdge(E origen, E destino){
        if(origen==null||destino==null) return false;
        Vertex<E> vo=searchVertex(origen);
        Vertex<E> vd=searchVertex(destino);
        if(vo==null||vd==null) return false;
//        Edge<E> e=new Edge<>(vo,vd,0);
        Edge<E> e=searchEdge(vo);
        vo.getEdges().remove(e);        
        if(!directed){
//          Edge<E> e=new Edge<>(vd,vo,0);
            e=searchEdge(vd);
            vd.getEdges().remove(vo);
        }return true;
    }
    
    private Edge<E> searchEdge(Vertex v){
        List<Edge<E>> edge= v.getEdges();
        for(Edge<E> e:edge){
            if(e.getOrigen().equals(v))return  e;    
        }return null;
    }
    
    public int indigree(E data){
        int cont=0;
        Vertex<E> v=searchVertex(data);       
        if(v==null) return 0;
        ListIterator<Vertex<E>> itv=vertexes.listIterator();
        while(itv.hasNext()){
            Vertex<E> vl=itv.next();
            ListIterator<Edge<E>> ite=vl.getEdges().listIterator();
            while(ite.hasNext()){
                Edge<E> e=ite.next();
                if(e.getDestino().equals(v)) cont+=1;
            }
        }
        return cont;
    }

    public int outdigree(E data){       
        Vertex<E> v=searchVertex(data);       
        if(v==null) return 0;
        return v.getEdges().size();
    }
    
    @Override
    public String toString(){
        if(isEmpty()){
            return(" V = { } , E = { }");
        }
        StringBuilder vertice=new StringBuilder ();
        vertice.append("V{");
        for(Vertex<E> v:vertexes){            
            vertice.append(v.getData()+",");         
        }
        vertice.substring(0,vertice.length()-1);
        vertice.append("}");
        
        StringBuilder tupla=  new StringBuilder();
        tupla.append("; E{");
        for(Vertex<E> v:vertexes){
            for(Edge<E> e: ( List<Edge<E>>) v.getEdges()){                
                    tupla.append("(" + e.getOrigen().getData() + ", "+ e.getDestino().getData()+")"+",");                                
            }       
        }
        tupla.substring(0,tupla.length()-1);
        tupla.append("}");
        
        return vertice.toString() + tupla.toString();
    }
    
    private void clearVertex(){
        for(Vertex<E> v:vertexes){
            v.setEstado(false);
        }
    }
    
    public List<E> bfs(E origen){
        List<E> l=new LinkedList<>();
        if(origen==null) return l;
        Vertex<E> v=searchVertex(origen);       
        if(v==null) return l;
        Queue<Vertex<E>> q=new LinkedList<>();
        v.setEstado(true);
        q.offer(v);
        while(!q.isEmpty()){
            v=q.poll();
            l.add(v.getData());
            for(Edge<E> e:(List<Edge<E>>) v.getEdges()){
                if(!e.getDestino().isEstado()){
                    e.getDestino().setEstado(true);
                    q.offer(e.getDestino());
                }
            }
        }clearVertex();
        return l;
    }
    
        public List<E> dfs(E origen){
        List<E> resultado=new ArrayList<>();
        Stack <Vertex<E>> pila=new Stack<>();
        Vertex <E> v=searchVertex(origen);
        if(v==null) return resultado;
        v.setEstado(true);
        pila.push(v);
        while(!pila.isEmpty()){
            v=pila.pop();
            resultado.add(v.getData());
            for(Edge <E> e:(List<Edge<E>>) v.getEdges()){
                if(!e.getDestino().isEstado()){
                    e.getDestino().setEstado(true);
                    pila.push(e.getDestino());
                }
            }
        }
        clearVertex();
        return resultado;
    }
        
    public GraphLA<E> reverse(){
        GraphLA<E> rev= new GraphLA<>(this.directed);
        if(isEmpty()||!this.directed) return this;
        for(Vertex<E> v:this.vertexes)
            rev.addVertex(v.getData());
        for(Vertex<E> v:this.vertexes){
            for(Edge<E> e:( List<Edge<E>>) v.getEdges()){
                rev.addEdge(e.getDestino().getData(),e.getOrigen().getData(), e.getPeso());
            }
        }return rev;
    }
    
    public List<List<E>> connectedComponents(){
        List<List<E>> list=new ArrayList<>();
        List<E> lista=new ArrayList<>();
        HashSet<E> origen=new HashSet<>();
            List<E> listaC=new ArrayList<>();
            HashSet<E> conjuntoOrig=new HashSet<>();
            HashSet<E> conjuntoInv=new HashSet<>();
            conjuntoOrig.addAll(this.dfs(vertexes.get(0).getData()));
            GraphLA<E>  grafo2=this.reverse();
            conjuntoInv.addAll(grafo2.dfs(grafo2.vertexes.get(0).getData()));
            conjuntoOrig.retainAll(conjuntoInv);
            listaC.addAll(conjuntoOrig);
            list.add(listaC);
            HashSet<E> vertices=new HashSet<>();
            for(Vertex<E> v: vertexes){
                vertices.add(v.getData());
            }
            vertices.removeAll(conjuntoOrig);
            while(!vertices.isEmpty()){
                List<E> listaW=new ArrayList<>();
                ArrayList<E> vert=new ArrayList<>(vertices);
                HashSet<E> conjuntoOrig2=new HashSet<>();
                HashSet<E> conjuntoInv2=new HashSet<>();
                conjuntoOrig2.addAll(this.dfs(vert.get(0)));
                conjuntoInv2.addAll(grafo2.dfs(vert.get(0)));
                conjuntoOrig2.retainAll(conjuntoInv2);
                listaW.addAll(conjuntoOrig2);
                list.add(listaW);
                HashSet<E> vertices2=new HashSet<>();
                for(E v: vert){
                    vertices2.add(v);
                }
                vertices2.removeAll(conjuntoOrig2);
                vertices=vertices2;
            }
        return list;       
    }
    
    
}
