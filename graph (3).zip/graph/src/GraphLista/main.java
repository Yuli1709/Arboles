/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GraphLista;

/**
 *
 * @author CltControl
 */
public class main {
    public static void main(String[] args) {
        // TODO code application logic here
        GraphLA<Integer> grafo = new GraphLA<>(true);
        grafo.addVertex(1);
        grafo.addVertex(2);
        grafo.addVertex(3);
        grafo.addVertex(4);
        grafo.addVertex(5);
        System.out.println(
        "     AÑADIR VERTICE     \n"+grafo.addVertex(6)+"\n"+
        "    AÑADIR ARISTA   \n"+grafo.addEdge(1,5,3)+"\n"+grafo.addEdge(7, 2, 4));
        grafo.addEdge(2,1,6);
        grafo.addEdge(5,1,6);
        grafo.addEdge(2,4,6);
        grafo.addEdge(4,2,6);
        grafo.addEdge(2,3,6);
        grafo.addEdge(4,6,2);
        grafo.addEdge(3,1,1);
        grafo.addEdge(10,5,3);
        System.out.println(
        "    ELIMINAR ARISTA   \n"+grafo.removeEdge(2,1)+"\n"+grafo.removeEdge(10,5)+"\n"+
        "    ELIMINAR Vertice   \n"+grafo.removeVertex(6)+"\n"+grafo.removeVertex(10)+"\n"+    
//        "    GRADO ENTRADA    \n"+grafo.indigree(1)+"\n"+grafo.indigree(20)+"\n"+
//        "    GRADO SALIDA    \n"+grafo.outdigree(2)+"\n"+grafo.outdigree(13)+"\n"+
        "    GRAFO    \n"+grafo.toString());
        
    }
}
