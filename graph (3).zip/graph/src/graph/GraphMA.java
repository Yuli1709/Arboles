/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graph;

import java.util.ArrayList;

/**
 *
 * @author Tania
 */
public class GraphMA <E>{
    private ArrayList<E> vertexes;
    private int [][] matrix;
    private boolean directed;

    public GraphMA(boolean directed) {
        this.directed = directed;
        vertexes= new ArrayList<>();
        matrix= new int[10][10];
    }
    
    public boolean isEmpty(){
        return vertexes.isEmpty();
    }
    
    public boolean addVertex(E data){
        if(data==null||vertexes.contains(data)) return false;
        return vertexes.add(data);
    }
    
    public boolean addEdge(E origen, E destino, int peso){
        if(origen==null||destino==null) return false;
        int io=vertexes.indexOf(origen);
        int id=vertexes.indexOf(destino);
        if(io<0||id<0) return false;
        matrix[io][id]=peso;
        if(!directed){
            matrix[id][io]=peso;
        }return true;
    }
    
    public boolean removeEdge(E origen, E destino){
        if(origen==null || destino==null) return false;
        int io=vertexes.indexOf(origen);
        int id=vertexes.indexOf(destino);
        if(io<0||id<0||matrix[io][id]==0) return false;
        matrix[io][id] = 0;
        if(!directed){
            matrix[id][io]=0;
        }return true;
    }   
    
    public boolean removeVertex(E data){
        int iv = vertexes.indexOf(data);
        if(iv<0) return false;
        for(int i=iv;i<vertexes.size();i++)
            matrix[i]=matrix[i+1];
        for(int j=iv; j<vertexes.size();j++)
        for(int i=0;i<vertexes.size();i++)
            matrix[i][j] = matrix[i][j+1];
            vertexes.remove(iv);
            
    return true;
    }    
 
    public int indigree(E data){
        int cont=0;       
        int indiceData=vertexes.indexOf(data);
        for(int i=0;i<vertexes.size();i++){
//            System.out.println(vertexes.indexOf(data));
           if( indiceData>-1 && (matrix[i][indiceData]!=0)){              
               cont+=1;
            }
        }
        return cont;
    }

    public int outdigree(E data){       
        if(!directed){
            return indigree(data);
        }
        int cont=0;
        int indiceData=vertexes.indexOf(data);        
        for(int j=0;j<vertexes.size();j++){
           if(indiceData>-1 && (matrix[indiceData][j]!=0)){
               cont+=1;
            }
        }
        return cont;
    }
    
    @Override
    public String toString(){
        if(isEmpty()){
            return(" V = { } , E = { }");
        }
        StringBuilder vertice=new StringBuilder ();
        vertice.append("V{");
        for(int i=0; i<vertexes.size();i++){            
            vertice.append(vertexes.get(i));
            if(i<vertexes.size()-1){
                vertice.append(",");
            }
        }
        vertice.substring(0,vertice.length()-1);
        vertice.append("}");
        int h=vertexes.size();
        StringBuilder tupla=  new StringBuilder();
        tupla.append("; E{");
        for(int i = 0;i<h;i++){
            for(int j= 0; j<h;j++){
                if(matrix[i][j] != 0 ){
                    tupla.append("(" + vertexes.get(i) + ", "+ vertexes.get(j)+")"+",");                
                }
            }       
        }
        tupla.substring(0,tupla.length()-1);
        tupla.append("}");
        return vertice.toString() + tupla.toString();
    }        

}
